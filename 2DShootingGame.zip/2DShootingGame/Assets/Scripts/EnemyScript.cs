﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyScript : MonoBehaviour
{
  private float phase;
  public GameObject Explosion;
    // Start is called before the first frame update
    void Start()
    {
      phase = Random.Range(0.0f, Mathf.PI * 2);

    }

    // Update is called once per frame
    void Update()
    {
        transform.position += new Vector3(
        Mathf.Cos(Time.frameCount * 0.05f) * 0.05f, //x軸
         -2.0f * Time.deltaTime, //y軸
          0.0f //z軸
          );
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
      if (collision.gameObject.CompareTag("Bullet")) {
        Destroy(collision.gameObject);
        Destroy(gameObject);
        Instantiate(Explosion, transform.position, transform.rotation);
      }
    }
}
